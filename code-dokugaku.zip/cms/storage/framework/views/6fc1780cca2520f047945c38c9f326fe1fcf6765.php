<?php $__env->startSection('content'); ?>
    <!-- if the number of error inside the errors array is more than 0 create the list  -->
        <?php echo $__env->make('admin.includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="panel panel-default">
            <div class="panel-heading">
                Update Category: <?php echo e($category->name); ?>

            </div>
            <div class="panel-body">
                <form action="<?php echo e(route('category.update', ['id' => $category->id])); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" value="<?php echo e($category->name); ?>" class="form-control">                        
                    </div>
                    
                    <div class="form-group">
                        <div class="text-center">
                            <button class="btn btn-success" type="submit">Update Category</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>