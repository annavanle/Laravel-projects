<?php $__env->startSection('content'); ?>
    <!-- if the number of error inside the errors array is more than 0 create the list  -->
        <?php if(count($errors) > 0): ?>
            <ul class="list-group">
            <!-- foreach of those error echo out a list item for user to see  -->
                <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item text-danger">
                        <?php echo e($error); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        <?php endif; ?> 
        <div class="panel panel-default">
            <div class="panel-heading">

              Create a new Category
            </div>
            <div class="panel-body">
                <form action="<?php echo e(route('category.store')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" class="form-control">                        
                    </div>
                    
                    <div class="form-group">
                        <div class="text-center">
                            <button class="btn btn-success" type="submit">Store Category</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>